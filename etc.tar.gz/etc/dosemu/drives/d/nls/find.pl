#Translated by Mateusz Viste "Fox" / the.killer@wp.pl
#Polish diacritics encoded with the MAZOVIA standard
0.0:Wy�wietla wszystkie linie pliku zawieraj�ce szukany tekst
0.1:Liczy ilo�� linii zawieraj�cych szukany tekst
0.2:Nie rozr��nia wielkich i ma�ych liter
0.3:Numeruje wy�wietlane linie, zaczynaj�c od 1
0.4:Wy�wietla linie kt�re nie zawieraj� szukanego tekstu
1.0:plik
1.1:szukany tekst
2.0:Nie mog� otworzy� pliku
2.1:Nie ma takiego pliku
2.2:Nie mog� przej�� do katalogu
