#Translated by Mateusz Viste "Fox" / the.killer@wp.pl
#Polish diacritics encoded with the MAZOVIA standard
0.0:Wy�wietla zawarto�� pliku tekstowego na ekranie strona po stronie
0.1:U�ycie
0.2:komenda
0.3:plik
0.4:Dost�pne klawisze
0.5:Nn
0.6:Nast�pny plik
0.7:Ww
0.8:Wyj�cie z programu
0.9:Spacja
0.10:Nast�pna strona
1.0:Nieznany parametr
1.1:Nie ma takiego pliku
1.2:Nie mo�na otworzy� pliku
2.0:Dalej
2.1:<STDIN>

1.3:opcja /Tabs musi by� /T1..9 (domy�lnie 4)
